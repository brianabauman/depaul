//
//  Configuration.swift
//  Bauman, Brian Mock Remote Control III
//
//  Created by Brian Bauman on 3/1/19.
//  Copyright © 2019 Brian Bauman. All rights reserved.
//

class Configuration {
    var labels: [String] = [ "AAA", "BBB", "CCC", "DDD" ];
    var channels: [String] = [ "01", "02", "03", "04" ];
}
